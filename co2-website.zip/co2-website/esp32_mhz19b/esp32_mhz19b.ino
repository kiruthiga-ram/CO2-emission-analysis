/*
  CO2 Monitor - ESP32 Web Server
  - Reads CO2 + temperature from MH-Z19B
  - Stores last 60 readings in memory
  - Hosts a live dashboard at http://<ESP32-IP>
  
  Libraries needed:
    - MHZ19 by Jonathan Dempsey
    - WiFi (built-in ESP32)
    - WebServer (built-in ESP32)

  Wiring:
    MH-Z19B VIN -> ESP32 VIN (5V)
    MH-Z19B GND -> ESP32 GND
    MH-Z19B TX  -> ESP32 GPIO16
    MH-Z19B RX  -> ESP32 GPIO17
*/

#include <WiFi.h>
#include <WebServer.h>
#include <MHZ19.h>
#include <HardwareSerial.h>

// ── CONFIGURE THESE ──────────────────────────────────────────
const char* WIFI_SSID     = "PAULRAJ";
const char* WIFI_PASSWORD = "9952555817";
// ─────────────────────────────────────────────────────────────

#define MAX_READINGS 60

struct Reading {
  int co2;
  int temperature;
  String status;
  String time;
};

Reading readings[MAX_READINGS];
int readingCount = 0;
int readingIndex = 0;

HardwareSerial mySerial(2);
MHZ19 myMHZ19;
WebServer server(80);
unsigned long lastRead = 0;
const unsigned long READ_INTERVAL = 10000;

int latestCO2 = 0;
int latestTemp = 0;
String latestStatus =  != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected: " + WiFi.localIP().toString());
  } else {
    Serial.println("\nWiFi failed! Status: " + String(WiFi.status()));
  }
}

void loop() {
  unsigned long now = millis();
  if (now - lastSend < SEND_INTERVAL) return;
  lastSend = now;

  int co2_ppm     = myMHZ19.getCO2();
  int temperature = myMHZ19.getTemperature();
if; min-height:100vh; }
  header { background:#111520; border-bottom:1px solid #1e2535; padding:20px 32px; display:flex; align-items:center; justify-content:space-between; }
  header h1 { font-size:1.1rem; font-weight:800; letter-spacing:0.1em; text-transform:uppercase; }
  header span { font-size:0.7rem; color:#4a5568; }
  .live-dot { width:8px; height:8px; border-radius:50%; background:#00e5a0; display:inline-block; margin-right:6px; animation:pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%
  String status;
  if      (co2_ppm >= 5000) status = "DANGER";
  else if (co2_ppm >= 1000) status = "WARNING";
  else                       status = "NORMAL";

  Serial.printf("CO2: %d ppm | Temp: %d C | %s\n", co2_ppm, temperature, status.c_str());
from{box-shadow:none} to{box-shadow:0 0 20px rgba(255,59,85,0.3)} }
  .card-label { font-size:0.65rem; color:#4a5568; letter-spacing:0.15em; text-transform:uppercase; margin-bottom:8px; }
  .card-value { font-size:2.2rem; font-weight:800; font-family:monospace; }
  .card-value.NORMAL  { color:#00e5a0; }
  .card-value.WARNING { color:#f5a623; }
  .card-value.DANGER  { color:#ff3b55; }
  .card-unit { font-size:0.7rem; color:#4a5568; margin-top:4px; }
  .status-badge { display:inline-block; padding:4px 12px; border-radius:4px; font-size:0.75rem; font-weight:700; letter-spacing:0.1em; margin-top:8px; }
  .NORMAL  .status-badge { background:rgba(0,229,160,0.15); color:#00e5a0; }
  .WARNING .status-badge { background:rgba(245,166,35,0.15); color:#f5a623; }
  .DANGER  .status-badge { background:rgba(255,59,85,0.15); color:#ff3b55; }
  .section-title { font-size:0.65rem; color:#4a5568; letter-spacing:0.2em; text-transform:uppercase; margin-bottom:16px; }
  table { width:100%; border-collapse:collapse; background:#111520; border-radius:12px; overflow:hidden; border:1px solid #1e2535; }
  thead th { background:#0a0d12; padding:10px 16px; font-size:0.6rem; letter-spacing:0.15em; text-transform:uppercase; color:#4a5568; text-align:left; border-bottom:1px solid #1e2535; }
  tbody td { padding:10px 16px; font-size:0.8rem; font-family:monospace; border-bottom:1px solid #1e2535; }
  tbody tr:last-child td { border-bottom:none; }
  .td-normal  { color:#00e5a0; }
  .td-warning { color:#f5a623; }
  .td-danger  { color:#ff3b55; }
  .legend { display:flex; gap:20px; margin-bottom:24px; flex-wrap:wrap; }
  .legend-item { display:flex; align-items:center; gap:6px; font-size:0.72rem; color:#4a5568; }
  .legend-dot { width:8px; height:8px; border-radius:50%; }
  .danger-alert { background:#1a0810; border:2px solid #ff3b55; border-radius:12px; padding:16px 24px; margin-bottom:24px; display:flex; align-items:center; gap:12px; }
  .danger-alert span { color:#ff3b55; font-weight:700; font-size:0.9rem; }
</style>
</head>
<body>
<header>
  <div>
    <h1>&#
  http.end();
}
"legend-dot" style="background:#00e5a0"></div>NORMAL &lt; 1000 ppm</div>
    <div class="legend-item"><div class="legend-dot" style="background:#f5a623"></div>WARNING 1000-4999 ppm</div>
    <div class="legend-item"><div class="legend-dot" style="background:#ff3b55"></div>DANGER &ge; 5000 ppm</div>
  </div>
  <div class="section-title">// current reading</div>
  <div class="cards">
)";

  // CO2 card
  html += "<div class='card " + latestStatus + "'>";
  html += "<div class='card-label'>CO&#8322; Level</div>";
  html += "<div class='card-value " + latestStatus + "'>" + String(latestCO2) + "</div>";
  html += "<div class='card-unit'>ppm</div>";
  html += "<div><span class='status-badge'>" + latestStatus + "</span></div>";
  html += "</div>";

  // Temperature card
  html += "<div class='card NORMAL'>";
  html += "<div class='card-label'>Temperature</div>";
  html += "<div class='card-value NORMAL'>" + String(latestTemp) + "</div>";
  html += "<div class='card-unit'>&deg;C</div>";
  html += "</div>";

  html += "</div>"; // end cards

  // History table
  html += "<div class='section-title'>// reading history (" + String(readingCount) + " readings)</div>";
  html += "<table><thead><tr><th>#</th><th>CO&#8322; (ppm)</th><th>Temp (&deg;C)</th><th>Status</th><th>Time</th></tr></thead><tbody>";

  int total = min(readingCount, MAX_READINGS);
  for (int i = total - 1; i >= 0; i--) {
    int idx = (readingIndex - 1 - i + MAX_READINGS) % MAX_READINGS;
    String cls = readings[idx].status == "DANGER" ? "td-danger" : readings[idx].status == "WARNING" ? "td-warning" : "td-normal";
    html += "<tr>";
    html += "<td style='color:#4a5568'>#" + String(total - i) + "</td>";
    html += "<td class='" + cls + "'>" + String(readings[idx].co2) + "</td>";
    html += "<td>" + String(readings[idx].temperature) + "</td>";
    html += "<td class='" + cls + "'>" + readings[idx].status + "</td>";
    html += "<td style='color:#4a5568'>" + readings[idx].time + "</td>";
    html += "</tr>";
  }

  html += "</tbody></table></main></body></html>";
  server.send(200, "text/html", html);
}

void handleData() {
  String json = "{\"co2\":" + String(latestCO2) + ",\"temperature\":" + String(latestTemp) + ",\"status\":\"" + latestStatus + "\"}";
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  delay(500);

  mySerial.begin(9600, SERIAL_8N1, 16, 17);
  myMHZ19.begin(mySerial);
  myMHZ19.autoCalibration(false);

  Serial.println("\n=== CO2 Web Server Starting ===");

  WiFi.disconnect(true);
  delay(1000);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to WiFi");
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.println("Open this in your browser: http://" + WiFi.localIP().toString());
  } else {
    Serial.println("\nWiFi failed! Status: " + String(WiFi.status()));
  }

  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.begin();
  Serial.println("Web server started.");
}

void loop() {
  server.handleClient();

  unsigned long now = millis();
  if (now - lastRead >= READ_INTERVAL) {
    lastRead = now;

    int co2  = myMHZ19.getCO2();
    int temp = myMHZ19.getTemperature();

    if (co2 <= 0) {
      Serial.println("Sensor not ready - skipping");
      return;
    }

    latestCO2    = co2;
    latestTemp   = temp;
    latestStatus = getStatus(co2);

    // Store reading
    readings[readingIndex].co2         = co2;
    readings[readingIndex].temperature = temp;
    readings[readingIndex].status      = latestStatus;
    readings[readingIndex].time        = String(millis() / 1000) + "s";
    readingIndex = (readingIndex + 1) % MAX_READINGS;
    if (readingCount < MAX_READINGS) readingCount++;

    Serial.printf("CO2: %d ppm | Temp: %d C | %s\n", co2, temp, latestStatus.c_str());
  }
}
