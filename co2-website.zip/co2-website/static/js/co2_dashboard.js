/**
 * DASHBOARD PAGE CONTROLLER
 * 7 ApexCharts: Area, Bar, Radial, Heatmap, Stacked, Scatter, Column
 */
const Dashboard = (() => {

  const COLORS = ['#00d4ff','#00ff9d','#ff8c42','#ffd166'];
  const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  let charts = {};
  let activeFacs = new Set(CO2_DATA.FACILITIES.map(f => f.id));

  /* ── HELPERS ── */
  const apexChart = (id, opts) => {
    const el = document.getElementById(id);
    if (!el) return null;
    if (charts[id]) { charts[id].destroy(); }
    charts[id] = new ApexCharts(el, opts);
    charts[id].render();
    return charts[id];
  };

  const baseChartOpts = {
    chart: { background: 'transparent' },
    grid: { borderColor: '#1e2d3d', strokeDashArray: 3 },
    tooltip: { theme: 'dark' },
    theme: { mode: 'dark' },
    legend: { labels: { colors: '#7a92a8' }, fontFamily: 'DM Sans' },
  };

  const axisStyle = {
    labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } }
  };

  /* ── STAT CARDS ── */
  function renderStatCards() {
    const s = CO2_DATA.globalStats();
    document.getElementById('dbTotalReadings').textContent = s.total?.toLocaleString();
    document.getElementById('dbMinCO2').textContent = s.minPPM + ' ppm';
    document.getElementById('dbMaxCO2').textContent = s.maxPPM + ' ppm';
    document.getElementById('dbAvgCO2').textContent = s.avgPPM + ' ppm';
  }

  /* ── 1. AREA CHART — FULL YEAR DAILY ── */
  function renderAreaYear() {
    const daily = CO2_DATA.dailyAverages();
    const days  = [...new Set(daily.map(r => r.day))].sort();

    // Build facility toggle buttons
    const wrap = document.getElementById('dashFacFilter');
    if (wrap && !wrap.children.length) {
      CO2_DATA.FACILITIES.forEach((f, i) => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-ghost btn-sm';
        btn.style.cssText = `color:${COLORS[i]};border-color:${COLORS[i]}44;font-family:var(--font-mono);font-size:0.65rem`;
        btn.textContent = f.id;
        btn.dataset.fac = f.id;
        btn.dataset.active = 'true';
        btn.onclick = () => {
          if (activeFacs.has(f.id)) { activeFacs.delete(f.id); btn.style.opacity='0.35'; btn.dataset.active='false'; }
          else                       { activeFacs.add(f.id);    btn.style.opacity='1';    btn.dataset.active='true'; }
          updateAreaYear();
        };
        wrap.appendChild(btn);
      });
    }

    const series = CO2_DATA.FACILITIES
      .filter(f => activeFacs.has(f.id))
      .map((f, i) => ({
        name: f.name,
        data: days.map(d => {
          const found = daily.find(r => r.day === d && r.facilityId === f.id);
          return found ? found.avg : null;
        })
      }));

    apexChart('chartAreaYear', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'area', height: 320,
               toolbar: { show: true, tools: { download: true, zoom: true, pan: true, reset: true } },
               animations: { enabled: true, speed: 800 } },
      series,
      xaxis: { categories: days, type: 'datetime',
               tickAmount: 12, ...axisStyle },
      yaxis: { title: { text: 'CO₂ ppm', style: { color: '#7a92a8', fontFamily: 'Space Mono' } }, ...axisStyle },
      stroke: { curve: 'smooth', width: 2 },
      fill: { type: 'gradient', gradient: { opacityFrom: 0.25, opacityTo: 0.0 } },
      colors: COLORS,
      dataLabels: { enabled: false },
      markers: { size: 0 },
      annotations: {
        yaxis: [
          { y: 800,  borderColor: '#f59e0b', strokeDashArray: 4,
            label: { text: 'WARNING', style: { color: '#f59e0b', background: 'transparent', fontFamily: 'Space Mono', fontSize: '9px' } } },
          { y: 1100, borderColor: '#ef4444', strokeDashArray: 4,
            label: { text: 'DANGER', style: { color: '#ef4444', background: 'transparent', fontFamily: 'Space Mono', fontSize: '9px' } } },
        ]
      },
    });
  }

  function updateAreaYear() { renderAreaYear(); }

  /* ── 2. MONTHLY BAR ── */
  function initBarSelects() {
    const monthly = CO2_DATA.monthlyTotals();
    const months  = [...new Set(monthly.map(r => r.month))].sort().reverse();
    const sel = document.getElementById('barMonthSel');
    if (!sel || sel.options.length > 0) return;
    months.forEach(m => { const o = new Option(m, m); sel.appendChild(o); });
  }

  function renderBarMonthly(month) {
    const monthly = CO2_DATA.monthlyTotals();
    const m = month || document.getElementById('barMonthSel')?.value;
    const data = CO2_DATA.FACILITIES.map(f => {
      const found = monthly.find(r => r.month === m && r.facilityId === f.id);
      return found ? found.avg : 0;
    });

    apexChart('chartBarMonthly', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'bar', height: 280,
               toolbar: { show: false } },
      series: [{ name: 'Avg CO₂ (ppm)', data }],
      xaxis: { categories: CO2_DATA.FACILITIES.map(f => f.name.split(' ')[0]+'\n'+f.name.split(' ').slice(1).join(' ')), ...axisStyle },
      yaxis: { ...axisStyle },
      colors: COLORS,
      plotOptions: { bar: { borderRadius: 5, distributed: true } },
      dataLabels: { enabled: true, formatter: v => v + ' ppm',
                    style: { fontFamily: 'Space Mono', fontSize: '10px', colors: ['#000'] } },
      legend: { show: false },
      annotations: {
        yaxis: [
          { y: 800,  borderColor: '#f59e0b44' },
          { y: 1100, borderColor: '#ef444444' },
        ]
      }
    });
  }

  function updateBar() {
    const m = document.getElementById('barMonthSel')?.value;
    renderBarMonthly(m);
  }

  /* ── 3. RADIAL GAUGE ── */
  function renderRadial() {
    const latest = CO2_DATA.latestPerFacility();
    // Show first 3 facilities as radial bars
    const facs = latest.slice(0, 3);
    const THRESHOLD = 1600; // max

    const series = facs.map(r => Math.round((r.co2_ppm / THRESHOLD) * 100));
    const labels = facs.map(r => r.facilityName.split(' ').slice(0,2).join(' '));

    apexChart('chartRadial', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'radialBar', height: 260 },
      series,
      labels,
      colors: ['#22c55e','#f59e0b','#00d4ff'],
      plotOptions: {
        radialBar: {
          hollow: { size: '25%', background: 'transparent' },
          track: { background: '#1e2d3d', strokeWidth: '97%' },
          dataLabels: {
            name: { color: '#7a92a8', fontSize: '10px', fontFamily: 'Space Mono' },
            value: { color: '#e8edf2', fontSize: '14px', fontFamily: 'Space Mono',
                     formatter: v => Math.round(v * THRESHOLD / 100) + ' ppm' }
          }
        }
      },
    });

    // Update text badges
    facs.forEach((r, i) => {
      const el = document.getElementById(`radFAC${i+1}`);
      if (el) el.textContent = r.co2_ppm + ' ppm';
    });
  }

  /* ── 4. HEATMAP ── */
  function initHeatmapSelect() {
    const sel = document.getElementById('heatFacSel');
    if (!sel || sel.options.length > 0) return;
    CO2_DATA.FACILITIES.forEach(f => sel.appendChild(new Option(f.name, f.id)));
  }

  function renderHeatmap(facId) {
    const fid = facId || document.getElementById('heatFacSel')?.value || CO2_DATA.FACILITIES[0].id;
    const rows = CO2_DATA.ALL_ROWS.filter(r => r.facilityId === fid);

    // hour (0-23) vs day-of-week
    const heatMatrix = {}; // { hour: { dow: [vals] } }
    rows.forEach(r => {
      const h = r.timestamp.getHours();
      const d = r.timestamp.getDay();
      if (!heatMatrix[h]) heatMatrix[h] = {};
      if (!heatMatrix[h][d]) heatMatrix[h][d] = [];
      heatMatrix[h][d].push(r.co2_ppm);
    });

    // Build series: 1 series per hour, data = 7 days
    const series = [];
    for (let h = 23; h >= 0; h--) {
      const data = DAYS.map((day, di) => {
        const arr = heatMatrix[h]?.[di] || [];
        if (!arr.length) return 0;
        return Math.round(arr.reduce((a,b) => a+b,0) / arr.length);
      });
      series.push({ name: `${String(h).padStart(2,'0')}:00`, data });
    }

    apexChart('chartHeatmap', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'heatmap', height: 260,
               toolbar: { show: false } },
      series,
      xaxis: { categories: DAYS, ...axisStyle },
      yaxis: { ...axisStyle },
      dataLabels: { enabled: false },
      colors: ['#00d4ff'],
      plotOptions: {
        heatmap: {
          shadeIntensity: 0.8,
          colorScale: {
            ranges: [
              { from: 0,    to: 799,  color: '#22c55e', name: 'Normal' },
              { from: 800,  to: 1099, color: '#f59e0b', name: 'Warning' },
              { from: 1100, to: 2000, color: '#ef4444', name: 'Danger' },
            ]
          }
        }
      },
    });
  }

  function updateHeatmap() {
    const fid = document.getElementById('heatFacSel')?.value;
    renderHeatmap(fid);
  }

  /* ── 5. STACKED ALERT EVENTS ── */
  function renderStackedAlerts() {
    const monthly = CO2_DATA.monthlyTotals();
    const months  = [...new Set(monthly.map(r => r.month))].sort();

    // Count status events per month
    const byMonth = {};
    months.forEach(m => { byMonth[m] = { NORMAL: 0, WARNING: 0, DANGER: 0 }; });

    CO2_DATA.ALL_ROWS.forEach(r => {
      const m = r.timestamp.toISOString().slice(0,7);
      if (byMonth[m]) byMonth[m][r.status]++;
    });

    apexChart('chartStackedAlerts', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'bar', height: 260,
               stacked: true, stackType: '100%',
               toolbar: { show: false } },
      series: [
        { name: 'Normal',  data: months.map(m => byMonth[m].NORMAL) },
        { name: 'Warning', data: months.map(m => byMonth[m].WARNING) },
        { name: 'Danger',  data: months.map(m => byMonth[m].DANGER) },
      ],
      xaxis: { categories: months, ...axisStyle },
      yaxis: { labels: { formatter: v => v + '%', ...axisStyle.labels } },
      colors: ['#22c55e','#f59e0b','#ef4444'],
      plotOptions: { bar: { borderRadius: 0, horizontal: false } },
      dataLabels: { enabled: false },
      fill: { opacity: 1 },
    });
  }

  /* ── 6. SCATTER — TEMP vs CO2 ── */
  function initScatterSelect() {
    const sel = document.getElementById('scatterFacSel');
    if (!sel || sel.options.length > 0) return;
    CO2_DATA.FACILITIES.forEach(f => sel.appendChild(new Option(f.name, f.id)));
  }

  function renderScatter(facId) {
    const fid = facId || document.getElementById('scatterFacSel')?.value || CO2_DATA.FACILITIES[0].id;
    const rows = CO2_DATA.ALL_ROWS.filter(r => r.facilityId === fid);

    // Sample 400 points
    const step = Math.max(1, Math.floor(rows.length / 400));
    const sampled = rows.filter((_, i) => i % step === 0).slice(0, 400);
    const byStatus = { NORMAL: [], WARNING: [], DANGER: [] };
    sampled.forEach(r => byStatus[r.status].push([r.temperature, r.co2_ppm]));

    apexChart('chartScatter', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'scatter', height: 260,
               toolbar: { show: false }, zoom: { enabled: false } },
      series: [
        { name: 'Normal',  data: byStatus.NORMAL },
        { name: 'Warning', data: byStatus.WARNING },
        { name: 'Danger',  data: byStatus.DANGER },
      ],
      xaxis: { title: { text: 'Temperature °C', style: { color: '#7a92a8', fontFamily: 'Space Mono' } }, ...axisStyle },
      yaxis: { title: { text: 'CO₂ ppm', style: { color: '#7a92a8', fontFamily: 'Space Mono' } }, ...axisStyle },
      colors: ['#22c55e','#f59e0b','#ef4444'],
      markers: { size: 3.5 },
      dataLabels: { enabled: false },
    });
  }

  function updateScatter() {
    renderScatter(document.getElementById('scatterFacSel')?.value);
  }

  /* ── 7. FLOW RATE COLUMN ── */
  function initFlowSelect() {
    const monthly = CO2_DATA.monthlyTotals();
    const months = [...new Set(monthly.map(r => r.month))].sort().reverse();
    const sel = document.getElementById('flowMonthSel');
    if (!sel || sel.options.length > 0) return;
    months.forEach(m => sel.appendChild(new Option(m, m)));
  }

  function renderFlow(month) {
    const m = month || document.getElementById('flowMonthSel')?.value;
    const rows = CO2_DATA.ALL_ROWS.filter(r => r.timestamp.toISOString().slice(0,7) === m);

    const byFac = {};
    CO2_DATA.FACILITIES.forEach(f => { byFac[f.id] = { sum: 0, count: 0, name: f.name }; });
    rows.forEach(r => {
      if (byFac[r.facilityId]) {
        byFac[r.facilityId].sum += r.flowRate;
        byFac[r.facilityId].count++;
      }
    });

    const data = CO2_DATA.FACILITIES.map(f => parseFloat((byFac[f.id].sum / (byFac[f.id].count || 1)).toFixed(1)));

    apexChart('chartFlow', {
      ...baseChartOpts,
      chart: { ...baseChartOpts.chart, type: 'bar', height: 260, toolbar: { show: false } },
      series: [{ name: 'Avg Flow Rate (m³/h)', data }],
      xaxis: { categories: CO2_DATA.FACILITIES.map(f => f.name.split(' ')[0]), ...axisStyle },
      yaxis: { title: { text: 'm³/h', style: { color: '#7a92a8', fontFamily: 'Space Mono' } }, ...axisStyle },
      colors: COLORS,
      plotOptions: { bar: { borderRadius: 4, distributed: true } },
      dataLabels: { enabled: true, formatter: v => v + ' m³/h',
                    style: { fontFamily: 'Space Mono', fontSize: '10px', colors: ['#000'] } },
      legend: { show: false },
    });
  }

  function updateFlow() {
    renderFlow(document.getElementById('flowMonthSel')?.value);
  }

  /* ── PUBLIC INIT ── */
  function init() {
    renderStatCards();
    renderAreaYear();

    initBarSelects();
    const defaultMonth = CO2_DATA.monthlyTotals().map(r => r.month).sort().reverse()[0];
    renderBarMonthly(defaultMonth);

    renderRadial();

    initHeatmapSelect();
    renderHeatmap();

    renderStackedAlerts();

    initScatterSelect();
    renderScatter();

    initFlowSelect();
    renderFlow();
  }

  return { init, updateAreaYear, updateBar, updateHeatmap, updateScatter, updateFlow };
})();
