/**
 * CO2 EMISSIONS MONITOR — DUMMY DATA ENGINE
 * Generates one full year of realistic industrial CO2 sensor data
 */

const CO2_DATA = (() => {

  /* ── SENSOR / FACILITY CONFIGURATION ── */
  const FACILITIES = [
    { id: "FAC-001", name: "Steel Plant Alpha",    location: "Zone A", baseLoad: 920, peakLoad: 1600 },
    { id: "FAC-002", name: "Cement Works Beta",   location: "Zone B", baseLoad: 780, peakLoad: 1400 },
    { id: "FAC-003", name: "Power Unit Gamma",    location: "Zone C", baseLoad: 650, peakLoad: 1200 },
    { id: "FAC-004", name: "Chemical Plant Delta", location: "Zone D", baseLoad: 500, peakLoad: 950  },
  ];

  const THRESHOLDS = { safe: 800, warning: 1100, danger: 1400 };

  /* ── HELPERS ── */
  function rand(min, max) { return Math.random() * (max - min) + min; }
  function randInt(min, max) { return Math.round(rand(min, max)); }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  /* seasonal multiplier: higher in winter (heating), lower in summer */
  function seasonal(month) {
    const curve = [1.15, 1.12, 1.05, 0.95, 0.88, 0.82, 0.80, 0.83, 0.90, 1.00, 1.08, 1.14];
    return curve[month];
  }

  /* shift multiplier: plants run heavier on day shifts */
  function shiftMult(hour) {
    if (hour >= 6  && hour < 14) return 1.20;
    if (hour >= 14 && hour < 22) return 1.10;
    return 0.85; // night shift
  }

  /* weekend reduction */
  function dayMult(dow) { return (dow === 0 || dow === 6) ? 0.72 : 1.0; }

  /* ── GENERATE FULL YEAR (hourly) ── */
  function generateYear() {
    const rows = [];
    const now  = new Date();
    const start = new Date(now);
    start.setFullYear(now.getFullYear() - 1);
    start.setMinutes(0, 0, 0);

    let cursor = new Date(start);
    let id = 1;

    while (cursor <= now) {
      const month = cursor.getMonth();
      const dow   = cursor.getDay();
      const hour  = cursor.getHours();
      const sm    = seasonal(month);
      const dm    = dayMult(dow);
      const shm   = shiftMult(hour);

      FACILITIES.forEach(fac => {
        const base  = fac.baseLoad * sm * dm * shm;
        const jitter = rand(-60, 60);
        // occasional spike events (shift change, maintenance restart)
        const spike = Math.random() < 0.03 ? rand(80, 200) : 0;
        const ppm   = clamp(Math.round(base + jitter + spike), 300, fac.peakLoad + 150);

        const temp  = parseFloat((rand(18, 35) * sm * 0.9).toFixed(1));
        const humidity = parseFloat(rand(30, 80).toFixed(1));
        const flowRate = parseFloat((rand(80, 200) * sm * dm).toFixed(2));

        rows.push({
          id: id++,
          timestamp: new Date(cursor),
          facilityId: fac.id,
          facilityName: fac.name,
          location: fac.location,
          co2_ppm: ppm,
          temperature: temp,
          humidity,
          flowRate,
          status: ppm >= THRESHOLDS.danger ? "DANGER"
                : ppm >= THRESHOLDS.warning ? "WARNING" : "NORMAL",
        });
      });

      cursor.setHours(cursor.getHours() + 1);
    }

    return rows;
  }

  /* ── AGGREGATE HELPERS ── */

  /** daily averages per facility — used in timeline charts */
  function dailyAverages(rows) {
    const map = {};
    rows.forEach(r => {
      const day = r.timestamp.toISOString().slice(0, 10);
      const key = `${day}|${r.facilityId}`;
      if (!map[key]) map[key] = { day, facilityId: r.facilityId, facilityName: r.facilityName, sum: 0, count: 0 };
      map[key].sum += r.co2_ppm;
      map[key].count++;
    });
    return Object.values(map).map(o => ({ ...o, avg: Math.round(o.sum / o.count) }))
                              .sort((a, b) => a.day.localeCompare(b.day));
  }

  /** monthly totals per facility */
  function monthlyTotals(rows) {
    const map = {};
    rows.forEach(r => {
      const mo  = r.timestamp.toISOString().slice(0, 7);
      const key = `${mo}|${r.facilityId}`;
      if (!map[key]) map[key] = { month: mo, facilityId: r.facilityId, facilityName: r.facilityName, sum: 0, count: 0, max: 0 };
      map[key].sum += r.co2_ppm;
      map[key].count++;
      if (r.co2_ppm > map[key].max) map[key].max = r.co2_ppm;
    });
    return Object.values(map).map(o => ({ ...o, avg: Math.round(o.sum / o.count) }))
                              .sort((a, b) => a.month.localeCompare(b.month));
  }

  /** latest reading per facility */
  function latestPerFacility(rows) {
    const map = {};
    rows.forEach(r => {
      if (!map[r.facilityId] || r.timestamp > map[r.facilityId].timestamp) {
        map[r.facilityId] = r;
      }
    });
    return Object.values(map);
  }

  /** past-N-hours average across all facilities */
  function recentHourlyTrend(rows, hours = 24) {
    const cutoff = new Date(Date.now() - hours * 3600 * 1000);
    const recent = rows.filter(r => r.timestamp >= cutoff);
    const byHour = {};
    recent.forEach(r => {
      const hKey = r.timestamp.toISOString().slice(0, 13);
      if (!byHour[hKey]) byHour[hKey] = { hour: hKey, sum: 0, count: 0 };
      byHour[hKey].sum += r.co2_ppm;
      byHour[hKey].count++;
    });
    return Object.values(byHour)
      .map(o => ({ hour: o.hour, avg: Math.round(o.sum / o.count) }))
      .sort((a, b) => a.hour.localeCompare(b.hour));
  }

  /** overall stats */
  function globalStats(rows) {
    if (!rows.length) return {};
    const ppms = rows.map(r => r.co2_ppm);
    const sum  = ppms.reduce((a, b) => a + b, 0);
    const dangerCount = rows.filter(r => r.status === "DANGER").length;
    const warnCount   = rows.filter(r => r.status === "WARNING").length;
    return {
      total:   rows.length,
      avgPPM:  Math.round(sum / rows.length),
      minPPM:  Math.min(...ppms),
      maxPPM:  Math.max(...ppms),
      dangerPct: ((dangerCount / rows.length) * 100).toFixed(1),
      warnPct:   ((warnCount  / rows.length) * 100).toFixed(1),
      normalPct: (((rows.length - dangerCount - warnCount) / rows.length) * 100).toFixed(1),
    };
  }

  /* ── STATUS LABEL UTIL ── */
  function statusLabel(ppm) {
    if (ppm >= THRESHOLDS.danger)  return { label: "DANGER",  color: "#ef4444" };
    if (ppm >= THRESHOLDS.warning) return { label: "WARNING", color: "#f59e0b" };
    return                                { label: "NORMAL",  color: "#22c55e" };
  }

  /* ── INIT: generate once, cache ── */
  console.time("CO2 data generation");
  const ALL_ROWS = generateYear();
  console.timeEnd("CO2 data generation");

  return {
    ALL_ROWS,
    FACILITIES,
    THRESHOLDS,
    dailyAverages: () => dailyAverages(ALL_ROWS),
    monthlyTotals: () => monthlyTotals(ALL_ROWS),
    latestPerFacility: () => latestPerFacility(ALL_ROWS),
    recentHourlyTrend: (h) => recentHourlyTrend(ALL_ROWS, h),
    globalStats: () => globalStats(ALL_ROWS),
    statusLabel,
    filterRows(opts = {}) {
      let r = ALL_ROWS;
      if (opts.facilityId)   r = r.filter(x => x.facilityId === opts.facilityId);
      if (opts.status)       r = r.filter(x => x.status === opts.status);
      if (opts.dateFrom)     r = r.filter(x => x.timestamp >= new Date(opts.dateFrom));
      if (opts.dateTo) {
        const to = new Date(opts.dateTo);
        to.setHours(23, 59, 59);
        r = r.filter(x => x.timestamp <= to);
      }
      if (opts.minPPM !== undefined) r = r.filter(x => x.co2_ppm >= opts.minPPM);
      if (opts.maxPPM !== undefined) r = r.filter(x => x.co2_ppm <= opts.maxPPM);
      return r;
    }
  };
})();
