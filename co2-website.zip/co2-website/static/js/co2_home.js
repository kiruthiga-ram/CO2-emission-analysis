/**
 * HOME PAGE CONTROLLER
 * Renders facility live-status cards + Home charts
 */
const Home = (() => {

  let chartTrend   = null;
  let chartPie     = null;
  let chartMonthly = null;

  const COLORS = ['#00d4ff','#00ff9d','#ff8c42','#ffd166'];

  const apex = (id, opts) => {
    const el = document.getElementById(id);
    if (!el) return null;
    const c = new ApexCharts(el, opts);
    c.render();
    return c;
  };

  /* ── FACILITY STATUS CARDS ── */
  function renderFacilityCards() {
    const latest  = CO2_DATA.latestPerFacility();
    const wrap    = document.getElementById('facilityCards');
    if (!wrap) return;

    let html = '';
    let dangerFacs = [];

    latest.forEach(r => {
      const pct = Math.min(100, Math.round((r.co2_ppm / 1600) * 100));
      const barColor = r.status === 'DANGER' ? 'var(--status-danger)'
                     : r.status === 'WARNING' ? 'var(--status-warning)'
                     : 'var(--status-normal)';

      if (r.status === 'DANGER') dangerFacs.push(r.facilityName);

      html += `
        <div class="facility-card status-${r.status}">
          <div class="facility-header">
            <div>
              <div class="facility-name">${r.facilityName}</div>
              <div class="facility-loc">📍 ${r.location}</div>
            </div>
            <span class="badge ${r.status.toLowerCase()}">${r.status}</span>
          </div>

          <div class="facility-ppm ${r.status}">${r.co2_ppm.toLocaleString()}</div>
          <div class="facility-sub">ppm CO₂</div>

          <div class="progress-bar-wrap">
            <div class="progress-bar-fill" style="width:${pct}%;background:${barColor}"></div>
          </div>

          <div class="mini-stats">
            <div class="mini-stat">
              <div class="mini-stat-label">Temp</div>
              <div class="mini-stat-val">${r.temperature}°C</div>
            </div>
            <div class="mini-stat">
              <div class="mini-stat-label">Humidity</div>
              <div class="mini-stat-val">${r.humidity}%</div>
            </div>
            <div class="mini-stat">
              <div class="mini-stat-label">Flow Rate</div>
              <div class="mini-stat-val">${r.flowRate} m³/h</div>
            </div>
            <div class="mini-stat">
              <div class="mini-stat-label">Sensor ID</div>
              <div class="mini-stat-val">${r.facilityId}</div>
            </div>
          </div>
        </div>`;
    });

    wrap.innerHTML = html;

    // Alert strip
    const strip = document.getElementById('homeAlertStrip');
    const alertText = document.getElementById('homeAlertText');
    if (dangerFacs.length) {
      alertText.textContent = `⚠ Critical CO₂ levels detected: ${dangerFacs.join(', ')}. Immediate action required.`;
      strip.style.display = 'flex';
    } else {
      strip.style.display = 'none';
    }

    // Update timestamp
    const ts = new Date();
    document.getElementById('homeLastUpdate').textContent =
      `Last updated: ${ts.toLocaleDateString()} ${ts.toLocaleTimeString()}`;
  }

  /* ── GLOBAL STAT CARDS ── */
  function renderStatCards() {
    const s = CO2_DATA.globalStats();
    document.getElementById('statAvgCO2').textContent = s.avgPPM?.toLocaleString() + ' ppm';
    document.getElementById('statNormal').textContent  = s.normalPct + '%';
    document.getElementById('statWarning').textContent = s.warnPct + '%';
    document.getElementById('statDanger').textContent  = s.dangerPct + '%';
  }

  /* ── 24H TREND CHART ── */
  function renderTrendChart() {
    const trend    = CO2_DATA.recentHourlyTrend(24);
    const labels   = trend.map(r => r.hour.slice(11));    // HH:mm
    const values   = trend.map(r => r.avg);

    const opts = {
      chart: {
        type: 'area', height: 240,
        background: 'transparent',
        toolbar: { show: false },
        animations: { enabled: true, easing: 'easeinout', speed: 600 }
      },
      series: [{ name: 'Avg CO₂ ppm', data: values }],
      xaxis: { categories: labels, labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      yaxis: { labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      stroke: { curve: 'smooth', width: 2 },
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.35, opacityTo: 0.02, stops: [0, 90] } },
      colors: ['#00d4ff'],
      grid: { borderColor: '#1e2d3d', strokeDashArray: 3 },
      dataLabels: { enabled: false },
      tooltip: { theme: 'dark', x: { format: 'HH:mm' } },
      annotations: {
        yaxis: [
          { y: 800,  borderColor: '#f59e0b', label: { text: 'WARNING', style: { color: '#f59e0b', background: 'transparent', fontFamily: 'Space Mono', fontSize: '9px' } } },
          { y: 1100, borderColor: '#ef4444', label: { text: 'DANGER',  style: { color: '#ef4444', background: 'transparent', fontFamily: 'Space Mono', fontSize: '9px' } } },
        ]
      },
      theme: { mode: 'dark' }
    };

    const el = document.getElementById('chartTrend24h');
    if (!el) return;
    if (chartTrend) { chartTrend.destroy(); chartTrend = null; }
    chartTrend = new ApexCharts(el, opts);
    chartTrend.render();

    // Populate facility dropdown
    const sel = document.getElementById('homeTrendFacility');
    if (sel && sel.options.length === 1) {
      CO2_DATA.FACILITIES.forEach(f => {
        const o = new Option(f.name, f.id);
        sel.appendChild(o);
      });
    }
  }

  /* ── STATUS PIE ── */
  function renderPieChart() {
    const s = CO2_DATA.globalStats();
    const el = document.getElementById('chartStatusPie');
    if (!el) return;

    if (chartPie) { chartPie.destroy(); chartPie = null; }
    chartPie = new ApexCharts(el, {
      chart: { type: 'donut', height: 240, background: 'transparent' },
      series: [parseFloat(s.normalPct), parseFloat(s.warnPct), parseFloat(s.dangerPct)],
      labels: ['Normal', 'Warning', 'Danger'],
      colors: ['#22c55e', '#f59e0b', '#ef4444'],
      legend: { position: 'bottom', labels: { colors: '#7a92a8' }, fontFamily: 'DM Sans' },
      dataLabels: { style: { fontFamily: 'Space Mono', fontSize: '11px' } },
      plotOptions: { pie: { donut: { size: '60%', labels: {
        show: true,
        total: { show: true, label: 'Readings', color: '#7a92a8', fontFamily: 'Space Mono',
                 formatter: w => w.globals.seriesTotals.reduce((a,b)=>a+b,0).toFixed(0)+'%' }
      } } } },
      tooltip: { theme: 'dark' },
      theme: { mode: 'dark' }
    });
    chartPie.render();
  }

  /* ── MONTHLY CHART ── */
  function renderMonthlyChart() {
    const monthly = CO2_DATA.monthlyTotals();
    const months  = [...new Set(monthly.map(r => r.month))].sort();
    const el = document.getElementById('chartMonthly');
    if (!el) return;

    const series = CO2_DATA.FACILITIES.map((fac, i) => ({
      name: fac.name,
      data: months.map(m => {
        const found = monthly.find(r => r.month === m && r.facilityId === fac.id);
        return found ? found.avg : null;
      })
    }));

    if (chartMonthly) { chartMonthly.destroy(); chartMonthly = null; }
    chartMonthly = new ApexCharts(el, {
      chart: { type: 'line', height: 280, background: 'transparent',
               toolbar: { show: true, tools: { download: true, zoom: true, pan: true } },
               animations: { enabled: true, speed: 800 } },
      series,
      xaxis: { categories: months, labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      yaxis: { title: { text: 'Avg CO₂ ppm', style: { color: '#7a92a8', fontFamily: 'Space Mono' } },
               labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      stroke: { curve: 'smooth', width: 2.5 },
      colors: COLORS,
      grid: { borderColor: '#1e2d3d', strokeDashArray: 3 },
      markers: { size: 3 },
      legend: { position: 'top', labels: { colors: '#7a92a8' }, fontFamily: 'DM Sans' },
      tooltip: { theme: 'dark' },
      annotations: {
        yaxis: [
          { y: 800,  borderColor: '#f59e0b33', fillColor: '#f59e0b11', label: { text: 'Warning Zone', style: { color: '#f59e0b', background: '#f59e0b22', fontFamily: 'Space Mono', fontSize: '9px' } } },
          { y: 1100, borderColor: '#ef444433', fillColor: '#ef444411', label: { text: 'Danger Zone', style: { color: '#ef4444', background: '#ef444422', fontFamily: 'Space Mono', fontSize: '9px' } } },
        ]
      },
      theme: { mode: 'dark' }
    });
    chartMonthly.render();
  }

  /* ── UPDATE TREND (facility selector) ── */
  function updateTrendChart() {
    const facId = document.getElementById('homeTrendFacility')?.value;
    let rows = CO2_DATA.ALL_ROWS;
    if (facId && facId !== 'all') rows = rows.filter(r => r.facilityId === facId);

    const cutoff = new Date(Date.now() - 24 * 3600 * 1000);
    const recent = rows.filter(r => r.timestamp >= cutoff);
    const byHour = {};
    recent.forEach(r => {
      const k = r.timestamp.toISOString().slice(0,13);
      if (!byHour[k]) byHour[k] = { sum:0, count:0 };
      byHour[k].sum += r.co2_ppm;
      byHour[k].count++;
    });
    const trend = Object.entries(byHour)
      .sort(([a],[b]) => a.localeCompare(b))
      .map(([h,v]) => ({ hour: h, avg: Math.round(v.sum/v.count) }));

    if (chartTrend) {
      chartTrend.updateSeries([{ name: 'Avg CO₂ ppm', data: trend.map(r => r.avg) }]);
      chartTrend.updateOptions({ xaxis: { categories: trend.map(r => r.hour.slice(11)) } });
    }
  }

  /* ── PUBLIC API ── */
  function init() {
    renderStatCards();
    renderFacilityCards();
    renderTrendChart();
    renderPieChart();
    renderMonthlyChart();
  }

  function refresh() {
    renderFacilityCards();
    renderStatCards();
  }

  return { init, refresh, updateTrendChart };
})();
