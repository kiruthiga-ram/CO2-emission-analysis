/**
 * REPORTS PAGE CONTROLLER
 * Filters, sorting, pagination, CSV export, mini charts
 */
const Reports = (() => {

  const PER_PAGE = 50;
  let filteredRows = [];
  let currentPage  = 1;
  let sortCol      = 'timestamp';
  let sortDir      = 'desc';
  let charts       = {};

  /* ── INIT ── */
  function init() {
    // Populate facility dropdown
    const facSel = document.getElementById('rptFacility');
    if (facSel && facSel.options.length === 1) {
      CO2_DATA.FACILITIES.forEach(f => facSel.appendChild(new Option(f.name, f.id)));
    }

    // Set default date range (1 year)
    const now   = new Date();
    const start = new Date(now);
    start.setFullYear(now.getFullYear() - 1);

    const fmt = d => d.toISOString().slice(0,10);
    const fromEl = document.getElementById('rptDateFrom');
    const toEl   = document.getElementById('rptDateTo');
    if (fromEl) fromEl.value = fmt(start);
    if (toEl)   toEl.value   = fmt(now);

    apply();
  }

  /* ── APPLY FILTERS ── */
  function apply() {
    const facId    = document.getElementById('rptFacility')?.value || '';
    const status   = document.getElementById('rptStatus')?.value || '';
    const dateFrom = document.getElementById('rptDateFrom')?.value || '';
    const dateTo   = document.getElementById('rptDateTo')?.value || '';
    const minPPM   = document.getElementById('rptMinPPM')?.value;
    const maxPPM   = document.getElementById('rptMaxPPM')?.value;

    filteredRows = CO2_DATA.filterRows({
      facilityId: facId || undefined,
      status:     status || undefined,
      dateFrom:   dateFrom || undefined,
      dateTo:     dateTo || undefined,
      minPPM:     minPPM ? parseInt(minPPM) : undefined,
      maxPPM:     maxPPM ? parseInt(maxPPM) : undefined,
    });

    currentPage = 1;
    sortRows();
    renderSummary();
    renderTable();
    renderPagination();
    renderMiniCharts();
  }

  /* ── RESET ── */
  function reset() {
    document.getElementById('rptFacility').value = '';
    document.getElementById('rptStatus').value   = '';
    document.getElementById('rptMinPPM').value   = '';
    document.getElementById('rptMaxPPM').value   = '';
    const now   = new Date();
    const start = new Date(now);
    start.setFullYear(now.getFullYear() - 1);
    document.getElementById('rptDateFrom').value = start.toISOString().slice(0,10);
    document.getElementById('rptDateTo').value   = now.toISOString().slice(0,10);
    apply();
  }

  /* ── SORT ── */
  function sort(col) {
    if (sortCol === col) { sortDir = sortDir === 'asc' ? 'desc' : 'asc'; }
    else                 { sortCol = col; sortDir = 'asc'; }

    // Update header classes
    document.querySelectorAll('#rptTable th').forEach(th => {
      th.classList.remove('sort-asc','sort-desc');
      if (th.dataset.col === col) th.classList.add(sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
    });

    currentPage = 1;
    sortRows();
    renderTable();
    renderPagination();
  }

  function sortRows() {
    filteredRows.sort((a, b) => {
      let av = a[sortCol], bv = b[sortCol];
      if (av instanceof Date) { av = av.getTime(); bv = bv.getTime(); }
      if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
      return sortDir === 'asc' ? av - bv : bv - av;
    });
  }

  /* ── SUMMARY STRIP ── */
  function renderSummary() {
    const count = filteredRows.length;
    document.getElementById('rptCount').textContent = count.toLocaleString();

    if (!count) {
      document.getElementById('rptAvgPPM').textContent = '—';
      document.getElementById('rptMaxPPMStat').textContent = '—';
      return;
    }

    const sum = filteredRows.reduce((a,r) => a + r.co2_ppm, 0);
    const max = Math.max(...filteredRows.map(r => r.co2_ppm));
    document.getElementById('rptAvgPPM').textContent    = Math.round(sum/count).toLocaleString();
    document.getElementById('rptMaxPPMStat').textContent = max.toLocaleString();
  }

  /* ── RENDER TABLE ── */
  function renderTable() {
    const tbody = document.getElementById('rptTableBody');
    if (!tbody) return;

    if (!filteredRows.length) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:40px;color:var(--text-muted)">No records match the selected filters.</td></tr>`;
      return;
    }

    const start = (currentPage - 1) * PER_PAGE;
    const page  = filteredRows.slice(start, start + PER_PAGE);

    tbody.innerHTML = page.map((r, idx) => {
      const ppmColor = r.status === 'DANGER' ? 'var(--status-danger)'
                     : r.status === 'WARNING' ? 'var(--status-warning)'
                     : 'var(--status-normal)';

      const ts = r.timestamp;
      const dateStr = `${ts.getFullYear()}-${String(ts.getMonth()+1).padStart(2,'0')}-${String(ts.getDate()).padStart(2,'0')}`;
      const timeStr = `${String(ts.getHours()).padStart(2,'0')}:${String(ts.getMinutes()).padStart(2,'0')}`;

      return `
        <tr>
          <td class="mono" style="color:var(--text-muted)">${start + idx + 1}</td>
          <td class="mono">${dateStr} <span style="color:var(--text-muted)">${timeStr}</span></td>
          <td style="color:var(--text-primary);font-weight:500">${r.facilityName}</td>
          <td style="color:var(--text-muted)">${r.location}</td>
          <td class="ppm-value" style="color:${ppmColor}">${r.co2_ppm.toLocaleString()}</td>
          <td class="mono">${r.temperature}</td>
          <td class="mono">${r.humidity}</td>
          <td class="mono">${r.flowRate}</td>
          <td><span class="badge ${r.status.toLowerCase()}">${r.status}</span></td>
        </tr>`;
    }).join('');
  }

  /* ── PAGINATION ── */
  function renderPagination() {
    const total = Math.ceil(filteredRows.length / PER_PAGE);
    document.getElementById('rptPageNum').textContent   = currentPage;
    document.getElementById('rptPageTotal').textContent = total || 1;
    document.getElementById('rptPerPageLabel').textContent = `${PER_PAGE} per page`;

    const wrap = document.getElementById('rptPagination');
    if (!wrap) return;

    const pages = [];
    pages.push({ label: '‹', val: currentPage - 1, disabled: currentPage <= 1 });

    // Windowed page numbers
    let lo = Math.max(1, currentPage - 2);
    let hi = Math.min(total, lo + 4);
    lo = Math.max(1, hi - 4);

    if (lo > 1) pages.push({ label: '1', val: 1 });
    if (lo > 2) pages.push({ label: '…', val: null });

    for (let i = lo; i <= hi; i++) pages.push({ label: String(i), val: i, active: i === currentPage });

    if (hi < total - 1) pages.push({ label: '…', val: null });
    if (hi < total)     pages.push({ label: String(total), val: total });

    pages.push({ label: '›', val: currentPage + 1, disabled: currentPage >= total });

    wrap.innerHTML = pages.map(p => {
      if (p.val === null) return `<span class="pg-btn" style="cursor:default">…</span>`;
      return `<button class="pg-btn ${p.active ? 'active' : ''}" ${p.disabled ? 'disabled' : ''} onclick="Reports.goPage(${p.val})">${p.label}</button>`;
    }).join('');
  }

  function goPage(n) {
    const total = Math.ceil(filteredRows.length / PER_PAGE);
    if (n < 1 || n > total) return;
    currentPage = n;
    renderTable();
    renderPagination();
    document.getElementById('rptTableWrap')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ── MINI CHARTS ── */
  function renderMiniCharts() {
    renderHistogram();
    renderTimeline();
  }

  function renderHistogram() {
    if (!filteredRows.length) return;

    // Bin into 100-ppm buckets
    const BINS = [400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600];
    const counts = BINS.map((lo, i) => {
      const hi = BINS[i+1] || 9999;
      return filteredRows.filter(r => r.co2_ppm >= lo && r.co2_ppm < hi).length;
    });
    const labels = BINS.map((b, i) => BINS[i+1] ? `${b}-${BINS[i+1]}` : `${b}+`);
    const colors = BINS.map(b =>
      b >= 1100 ? '#ef4444' : b >= 800 ? '#f59e0b' : '#22c55e'
    );

    const el = document.getElementById('chartRptHistogram');
    if (!el) return;
    if (charts.hist) charts.hist.destroy();
    charts.hist = new ApexCharts(el, {
      chart: { type: 'bar', height: 220, background: 'transparent', toolbar: { show: false } },
      series: [{ name: 'Count', data: counts }],
      xaxis: { categories: labels, labels: { rotate: -45, style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '9px' } } },
      yaxis: { labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      colors: [({ dataPointIndex: i }) => colors[i] || '#00d4ff'],
      plotOptions: { bar: { borderRadius: 2, distributed: true } },
      dataLabels: { enabled: false },
      grid: { borderColor: '#1e2d3d', strokeDashArray: 3 },
      legend: { show: false },
      tooltip: { theme: 'dark' },
      theme: { mode: 'dark' }
    });
    charts.hist.render();
  }

  function renderTimeline() {
    if (!filteredRows.length) return;

    // Aggregate daily average from filtered rows
    const byDay = {};
    filteredRows.forEach(r => {
      const d = r.timestamp.toISOString().slice(0,10);
      if (!byDay[d]) byDay[d] = { sum:0, count:0 };
      byDay[d].sum += r.co2_ppm;
      byDay[d].count++;
    });

    const days = Object.keys(byDay).sort();
    // Sample max 90 points
    const step = Math.max(1, Math.floor(days.length / 90));
    const sampled = days.filter((_, i) => i % step === 0);
    const data = sampled.map(d => Math.round(byDay[d].sum / byDay[d].count));

    const el = document.getElementById('chartRptTimeline');
    if (!el) return;
    if (charts.timeline) charts.timeline.destroy();
    charts.timeline = new ApexCharts(el, {
      chart: { type: 'line', height: 220, background: 'transparent', toolbar: { show: false }, sparkline: { enabled: false } },
      series: [{ name: 'Avg CO₂', data }],
      xaxis: { categories: sampled, tickAmount: 6, labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '9px' } } },
      yaxis: { labels: { style: { colors: '#7a92a8', fontFamily: 'Space Mono', fontSize: '10px' } } },
      stroke: { curve: 'smooth', width: 2 },
      colors: ['#00d4ff'],
      fill: { type: 'gradient', gradient: { opacityFrom: 0.25, opacityTo: 0.0 } },
      dataLabels: { enabled: false },
      markers: { size: 0 },
      grid: { borderColor: '#1e2d3d', strokeDashArray: 3 },
      tooltip: { theme: 'dark' },
      annotations: {
        yaxis: [
          { y: 800,  borderColor: '#f59e0b44' },
          { y: 1100, borderColor: '#ef444444' },
        ]
      },
      theme: { mode: 'dark' }
    });
    charts.timeline.render();
  }

  /* ── CSV EXPORT ── */
  function exportCSV() {
    const headers = ['ID','Timestamp','Facility','Location','CO2 (ppm)','Temperature','Humidity','Flow Rate','Status'];
    const rows = filteredRows.map((r, i) => [
      i+1,
      r.timestamp.toISOString(),
      r.facilityName,
      r.location,
      r.co2_ppm,
      r.temperature,
      r.humidity,
      r.flowRate,
      r.status
    ]);

    const csv = [headers, ...rows].map(r => r.map(v => `"${v}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `co2_report_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /* ── PRINT ── */
  function printTable() {
    window.print();
  }

  return { init, apply, reset, sort, goPage, exportCSV, printTable };
})();
